function [B] = jac_u(X0,U0,f)
% Write your jacobian function here using finite differences

% B = ...

error('Remove this when you have implemented the function')
