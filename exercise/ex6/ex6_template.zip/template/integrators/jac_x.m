function [A] = jac_x(X0,U0,f)
% Write your jacobian function here using finite differences

% A = ...

error('Remove this when you have implemented the function')
